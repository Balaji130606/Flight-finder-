const express = require("express");
const router = express.Router();
// Future user-related routes can go here
module.exports = router;
